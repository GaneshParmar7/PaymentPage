<script>
	import { Theme, Button } from 'carbon-components-svelte';
	import 'carbon-components-svelte/css/all.css';
</script>

<slot />

<Theme
	theme="white"
/>

<style>
        
</style>