<script>
	import PaymentPage from "./PaymentPage.svelte";

</script>
<PaymentPage />